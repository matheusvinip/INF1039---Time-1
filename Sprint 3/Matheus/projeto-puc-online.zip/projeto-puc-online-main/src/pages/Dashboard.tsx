import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import DashboardHeader from "@/components/DashboardHeader";
import SAUTab from "@/components/tabs/SAUTab";
import RequerimentosTab from "@/components/tabs/RequerimentosTab";
import CCEADTab from "@/components/tabs/CCEADTab";
import DiplomasTab from "@/components/tabs/DiplomasTab";
import { BookOpen, FileText, Monitor, Award } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const tabs = [
  { id: "sau", label: "SAU", fullLabel: "Sistema Acadêmico Universitário", icon: BookOpen },
  { id: "requerimentos", label: "Requerimentos", fullLabel: "Requerimentos Acadêmicos", icon: FileText },
  { id: "ccead", label: "CCEAD", fullLabel: "Ambiente de Aprendizagem Online", icon: Monitor },
  { id: "diplomas", label: "Diplomas", fullLabel: "Consulta de Diplomas Emitidos", icon: Award },
];

export type UserProfile = {
  nome: string;
  sobrenome: string;
  matricula: string;
  curso: string;
  email: string;
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("sau");
  const [profile, setProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/");
        return;
      }

      const { data } = await supabase
        .from("profiles")
        .select("nome, sobrenome, matricula, curso, email")
        .eq("user_id", session.user.id)
        .single();

      if (data) setProfile(data);
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT") navigate("/");
    });

    checkAuth();
    return () => subscription.unsubscribe();
  }, [navigate]);

  if (!profile) return null;

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader profile={profile} />

      <div className="border-b bg-card">
        <div className="container mx-auto px-4">
          <nav className="flex overflow-x-auto gap-0 -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab.id ? "puc-tab-active" : "puc-tab-inactive hover:text-foreground"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      <div className="container mx-auto px-4 pt-4 pb-2">
        <p className="text-xs text-muted-foreground">
          {tabs.find((t) => t.id === activeTab)?.fullLabel}
        </p>
      </div>

      <main className="container mx-auto px-4 pb-8">
        {activeTab === "sau" && <SAUTab />}
        {activeTab === "requerimentos" && <RequerimentosTab />}
        {activeTab === "ccead" && <CCEADTab />}
        {activeTab === "diplomas" && <DiplomasTab />}
      </main>
    </div>
  );
};

export default Dashboard;
