import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Eye, EyeOff, GraduationCap } from "lucide-react";
import campusHero from "@/assets/campus-hero.jpg";
import pucLogo from "@/assets/puc-logo.png";
import { supabase } from "@/integrations/supabase/client";

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !senha) {
      toast.error("Preencha todos os campos");
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password: senha,
    });
    setLoading(false);

    if (error) {
      toast.error("E-mail ou senha inválidos. Verifique seus dados ou crie uma conta.");
      return;
    }

    toast.success("Login realizado com sucesso!");
    navigate("/dashboard");
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) {
      toast.error("Informe seu e-mail institucional");
      return;
    }
    await supabase.auth.resetPasswordForEmail(forgotEmail, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    toast.success("E-mail de recuperação enviado!");
    setShowForgot(false);
  };

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <img src={campusHero} alt="Campus universitário" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 puc-gradient-bg opacity-70" />
        <div className="relative z-10 flex flex-col justify-end p-12 text-primary-foreground">
          <h2 className="font-display text-4xl font-bold mb-3">Bem-vindo ao PUC Online</h2>
          <p className="text-lg opacity-90 max-w-md">
            Acesse seus serviços acadêmicos, consulte notas, solicite requerimentos e muito mais.
          </p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md animate-fade-in">
          <div className="flex flex-col items-center mb-8">
            <img src={pucLogo} alt="PUC Logo" className="w-20 h-20 mb-4" />
            <h1 className="font-display text-3xl font-bold text-primary">PUC Online</h1>
            <p className="text-muted-foreground mt-1">Sistema Acadêmico</p>
          </div>

          {!showForgot ? (
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground font-medium">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu.email@puc.edu.br"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="senha" className="text-foreground font-medium">Senha</Label>
                <div className="relative">
                  <Input
                    id="senha"
                    type={showPassword ? "text" : "password"}
                    placeholder="Digite sua senha"
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                    className="h-12 pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <Button type="submit" className="w-full h-12 text-base font-semibold" disabled={loading}>
                <GraduationCap className="w-5 h-5 mr-2" />
                {loading ? "Entrando..." : "Entrar"}
              </Button>

              <button
                type="button"
                onClick={() => setShowForgot(true)}
                className="w-full text-center text-sm text-primary hover:underline font-medium"
              >
                Esqueci minha senha
              </button>

              <p className="text-center text-sm text-muted-foreground">
                Não tem conta?{" "}
                <Link to="/register" className="text-primary font-medium hover:underline">
                  Criar conta
                </Link>
              </p>
            </form>
          ) : (
            <form onSubmit={handleForgot} className="space-y-5">
              <div className="puc-card p-4 mb-4">
                <p className="text-sm text-muted-foreground">
                  Informe seu e-mail institucional para receber o link de recuperação de senha.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="forgotEmail" className="text-foreground font-medium">E-mail institucional</Label>
                <Input
                  id="forgotEmail"
                  type="email"
                  placeholder="seu.email@puc.edu.br"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  className="h-12"
                />
              </div>
              <Button type="submit" className="w-full h-12 text-base font-semibold">
                Enviar link de recuperação
              </Button>
              <button
                type="button"
                onClick={() => setShowForgot(false)}
                className="w-full text-center text-sm text-primary hover:underline font-medium"
              >
                Voltar ao login
              </button>
            </form>
          )}

          <p className="text-xs text-muted-foreground text-center mt-8">
            © 2026 PUC Online — Todos os direitos reservados
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
