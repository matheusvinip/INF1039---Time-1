import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { UserPlus } from "lucide-react";
import pucLogo from "@/assets/puc-logo.png";
import { supabase } from "@/integrations/supabase/client";

const Register = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    nome: "",
    sobrenome: "",
    email: "",
    matricula: "",
    curso: "",
    senha: "",
    confirmarSenha: "",
  });

  const update = (field: string, value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    const { nome, sobrenome, email, matricula, curso, senha, confirmarSenha } = form;

    if (!nome || !sobrenome || !email || !matricula || !curso || !senha) {
      toast.error("Preencha todos os campos");
      return;
    }
    if (senha !== confirmarSenha) {
      toast.error("As senhas não coincidem");
      return;
    }
    if (senha.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres");
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password: senha,
      options: {
        data: { nome, sobrenome, matricula, curso },
      },
    });
    setLoading(false);

    if (error) {
      toast.error(error.message);
      return;
    }

    toast.success("Conta criada com sucesso! Faça login.");
    navigate("/");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-8 bg-background">
      <div className="w-full max-w-lg animate-fade-in">
        <div className="flex flex-col items-center mb-8">
          <img src={pucLogo} alt="PUC Logo" className="w-16 h-16 mb-3" />
          <h1 className="font-display text-2xl font-bold text-primary">Criar Conta</h1>
          <p className="text-muted-foreground mt-1 text-sm">Cadastre-se no PUC Online</p>
        </div>

        <form onSubmit={handleRegister} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nome" className="text-foreground font-medium">Nome</Label>
              <Input id="nome" placeholder="João" value={form.nome} onChange={(e) => update("nome", e.target.value)} className="h-11" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sobrenome" className="text-foreground font-medium">Sobrenome</Label>
              <Input id="sobrenome" placeholder="Silva" value={form.sobrenome} onChange={(e) => update("sobrenome", e.target.value)} className="h-11" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-foreground font-medium">E-mail institucional</Label>
            <Input id="email" type="email" placeholder="seu.email@puc.edu.br" value={form.email} onChange={(e) => update("email", e.target.value)} className="h-11" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="matricula" className="text-foreground font-medium">Matrícula</Label>
              <Input id="matricula" placeholder="2024010001" value={form.matricula} onChange={(e) => update("matricula", e.target.value)} className="h-11" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="curso" className="text-foreground font-medium">Curso</Label>
              <Input id="curso" placeholder="Engenharia de Software" value={form.curso} onChange={(e) => update("curso", e.target.value)} className="h-11" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="senha" className="text-foreground font-medium">Senha</Label>
              <Input id="senha" type="password" placeholder="Mín. 6 caracteres" value={form.senha} onChange={(e) => update("senha", e.target.value)} className="h-11" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmarSenha" className="text-foreground font-medium">Confirmar Senha</Label>
              <Input id="confirmarSenha" type="password" placeholder="Repita a senha" value={form.confirmarSenha} onChange={(e) => update("confirmarSenha", e.target.value)} className="h-11" />
            </div>
          </div>

          <Button type="submit" className="w-full h-12 text-base font-semibold mt-2" disabled={loading}>
            <UserPlus className="w-5 h-5 mr-2" />
            {loading ? "Criando..." : "Criar Conta"}
          </Button>

          <p className="text-center text-sm text-muted-foreground">
            Já tem uma conta?{" "}
            <Link to="/" className="text-primary font-medium hover:underline">
              Fazer login
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Register;
