import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Award, Search, Download, FileCheck, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const diplomas = [
  {
    curso: "Bacharelado em Engenharia de Software",
    tipo: "Graduação",
    dataEmissao: null,
    registro: null,
    status: "Em andamento",
  },
];

const diplomasEmitidos = [
  {
    curso: "Técnico em Informática",
    tipo: "Curso Técnico",
    dataEmissao: "15/12/2022",
    registro: "REG-2022-004521",
    status: "Emitido",
  },
];

const DiplomasTab = () => {
  const [search, setSearch] = useState("");

  const allDiplomas = [...diplomasEmitidos, ...diplomas];
  const filtered = allDiplomas.filter((d) =>
    d.curso.toLowerCase().includes(search.toLowerCase())
  );

  const handleDownload = (curso: string) => {
    // Simulate PDF download
    const blob = new Blob(
      [`DIPLOMA\n\nCertificamos que o aluno concluiu o curso de ${curso}.\n\nData de emissão: ${new Date().toLocaleDateString("pt-BR")}`],
      { type: "application/pdf" }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Diploma_${curso.replace(/\s+/g, "_")}.pdf`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Download do diploma iniciado!");
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <h3 className="font-display text-xl font-bold text-foreground">Consulta de Diplomas Emitidos</h3>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar por curso..."
          className="pl-10"
        />
      </div>

      <div className="space-y-3">
        {filtered.map((d, i) => (
          <Card key={i}>
            <CardContent className="p-5 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-accent">
                {d.status === "Emitido" ? (
                  <FileCheck className="w-6 h-6 text-puc-success" />
                ) : (
                  <AlertCircle className="w-6 h-6 text-puc-warning" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground">{d.curso}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{d.tipo}</p>
                {d.registro && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Registro: {d.registro} | Emissão: {d.dataEmissao}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className={d.status === "Emitido" ? "puc-badge-success" : "puc-badge-warning"}>
                  {d.status}
                </span>
                {d.status === "Emitido" && (
                  <Button variant="outline" size="sm" onClick={() => handleDownload(d.curso)}>
                    <Download className="w-3 h-3 mr-1" />
                    PDF
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <Award className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground">Nenhum diploma encontrado</p>
        </div>
      )}
    </div>
  );
};

export default DiplomasTab;
