import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Video, FileText, MessageSquare, ExternalLink, Clock,
  ArrowLeft, Plus, Send
} from "lucide-react";

type Forum = { titulo: string; autor: string; respostas: number; data: string };

const cursosData = [
  {
    nome: "Banco de Dados II",
    professor: "Prof. Dr. Carlos Mendes",
    atividades: 3,
    proximaEntrega: "12/04/2026",
    progresso: 65,
    videoaulas: [
      { titulo: "Aula 1 — Modelagem Relacional Avançada", duracao: "45min", data: "01/03/2026" },
      { titulo: "Aula 2 — Normalização e Desnormalização", duracao: "52min", data: "08/03/2026" },
      { titulo: "Aula 3 — Índices e Performance", duracao: "38min", data: "15/03/2026" },
    ],
    materiais: [
      { titulo: "Slides — Modelagem Relacional", tipo: "PDF", tamanho: "2.3 MB" },
      { titulo: "Apostila — Normalização", tipo: "PDF", tamanho: "5.1 MB" },
      { titulo: "Exercícios — Índices", tipo: "DOCX", tamanho: "1.2 MB" },
    ],
    foruns: [
      { titulo: "Dúvida sobre 3FN", autor: "Maria Santos", respostas: 4, data: "10/03/2026" },
      { titulo: "Exercício 3 — Índices", autor: "Pedro Lima", respostas: 2, data: "16/03/2026" },
    ],
  },
  {
    nome: "Engenharia de Software",
    professor: "Profa. Dra. Ana Lúcia",
    atividades: 1,
    proximaEntrega: "15/04/2026",
    progresso: 72,
    videoaulas: [
      { titulo: "Aula 1 — Processos de Software", duracao: "50min", data: "02/03/2026" },
      { titulo: "Aula 2 — Metodologias Ágeis", duracao: "47min", data: "09/03/2026" },
    ],
    materiais: [
      { titulo: "Slides — Processos de Software", tipo: "PDF", tamanho: "3.0 MB" },
      { titulo: "Artigo — Scrum na Prática", tipo: "PDF", tamanho: "1.8 MB" },
    ],
    foruns: [
      { titulo: "Scrum vs Kanban", autor: "Lucas Oliveira", respostas: 7, data: "12/03/2026" },
    ],
  },
  {
    nome: "Redes de Computadores",
    professor: "Prof. Ms. Roberto Silva",
    atividades: 2,
    proximaEntrega: "10/04/2026",
    progresso: 45,
    videoaulas: [
      { titulo: "Aula 1 — Modelo OSI", duracao: "42min", data: "03/03/2026" },
      { titulo: "Aula 2 — TCP/IP", duracao: "55min", data: "10/03/2026" },
      { titulo: "Aula 3 — Sub-redes", duracao: "40min", data: "17/03/2026" },
    ],
    materiais: [
      { titulo: "Slides — Modelo OSI", tipo: "PDF", tamanho: "2.8 MB" },
      { titulo: "Lab — Configuração de Redes", tipo: "PDF", tamanho: "4.5 MB" },
    ],
    foruns: [
      { titulo: "Cálculo de sub-redes", autor: "Ana Clara", respostas: 5, data: "18/03/2026" },
      { titulo: "Wireshark — captura de pacotes", autor: "João Pedro", respostas: 3, data: "20/03/2026" },
    ],
  },
  {
    nome: "Inteligência Artificial",
    professor: "Prof. Dr. Paulo Fernandes",
    atividades: 0,
    proximaEntrega: "20/04/2026",
    progresso: 80,
    videoaulas: [
      { titulo: "Aula 1 — Introdução à IA", duracao: "48min", data: "04/03/2026" },
      { titulo: "Aula 2 — Aprendizado Supervisionado", duracao: "53min", data: "11/03/2026" },
    ],
    materiais: [
      { titulo: "Slides — Introdução à IA", tipo: "PDF", tamanho: "3.5 MB" },
      { titulo: "Dataset — Iris", tipo: "CSV", tamanho: "0.1 MB" },
    ],
    foruns: [
      { titulo: "Recomendação de livros sobre ML", autor: "Fernanda Costa", respostas: 6, data: "14/03/2026" },
    ],
  },
];

type DisciplinaView = "videoaulas" | "materiais" | "foruns" | null;

const CCEADTab = () => {
  const [selectedCurso, setSelectedCurso] = useState<number | null>(null);
  const [view, setView] = useState<DisciplinaView>(null);
  const [foruns, setForuns] = useState<Record<number, Forum[]>>(() => {
    const map: Record<number, Forum[]> = {};
    cursosData.forEach((c, i) => { map[i] = [...c.foruns]; });
    return map;
  });
  const [novoForum, setNovoForum] = useState("");

  if (selectedCurso === null) {
    return (
      <div className="space-y-6 animate-fade-in">
        <h3 className="font-display text-xl font-bold text-foreground">CCEAD — Ambiente de Aprendizagem Online</h3>
        <div>
          <h4 className="font-semibold text-foreground mb-3">Minhas Disciplinas</h4>
          <div className="space-y-3">
            {cursosData.map((c, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground">{c.nome}</p>
                      <p className="text-xs text-muted-foreground">{c.professor}</p>
                      <div className="flex items-center gap-4 mt-2">
                        {c.atividades > 0 && (
                          <span className="puc-badge-warning">
                            {c.atividades} atividade{c.atividades > 1 ? "s" : ""} pendente{c.atividades > 1 ? "s" : ""}
                          </span>
                        )}
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          Entrega: {c.proximaEntrega}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-lg font-bold text-primary">{c.progresso}%</p>
                        <p className="text-xs text-muted-foreground">concluído</p>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setSelectedCurso(i)}>
                        <ExternalLink className="w-3 h-3 mr-1" />
                        Acessar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const curso = cursosData[selectedCurso];

  const handleCriarForum = () => {
    if (!novoForum.trim()) return;
    const novo: Forum = {
      titulo: novoForum,
      autor: "Você",
      respostas: 0,
      data: new Date().toLocaleDateString("pt-BR"),
    };
    setForuns((prev) => ({ ...prev, [selectedCurso]: [novo, ...prev[selectedCurso]] }));
    setNovoForum("");
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => { setSelectedCurso(null); setView(null); }}>
          <ArrowLeft className="w-4 h-4 mr-1" />
          Voltar
        </Button>
        <div>
          <h3 className="font-display text-xl font-bold text-foreground">{curso.nome}</h3>
          <p className="text-xs text-muted-foreground">{curso.professor}</p>
        </div>
      </div>

      {/* Resource buttons */}
      {!view && (
        <div className="grid grid-cols-3 gap-3">
          <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setView("videoaulas")}>
            <CardContent className="p-4 text-center">
              <Video className="w-8 h-8 mx-auto mb-2 text-primary" />
              <p className="font-medium text-foreground text-sm">Videoaulas</p>
              <p className="text-xs text-muted-foreground mt-1">{curso.videoaulas.length} disponíveis</p>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setView("materiais")}>
            <CardContent className="p-4 text-center">
              <FileText className="w-8 h-8 mx-auto mb-2 text-primary" />
              <p className="font-medium text-foreground text-sm">Material Didático</p>
              <p className="text-xs text-muted-foreground mt-1">{curso.materiais.length} arquivos</p>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setView("foruns")}>
            <CardContent className="p-4 text-center">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 text-primary" />
              <p className="font-medium text-foreground text-sm">Fóruns</p>
              <p className="text-xs text-muted-foreground mt-1">{foruns[selectedCurso].length} tópicos</p>
            </CardContent>
          </Card>
        </div>
      )}

      {view && (
        <Button variant="outline" size="sm" onClick={() => setView(null)}>
          <ArrowLeft className="w-4 h-4 mr-1" />
          Voltar aos recursos
        </Button>
      )}

      {/* Videoaulas */}
      {view === "videoaulas" && (
        <div className="space-y-3">
          <h4 className="font-semibold text-foreground">Videoaulas</h4>
          {curso.videoaulas.map((v, i) => (
            <Card key={i}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-2 rounded-lg bg-accent">
                  <Video className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground text-sm">{v.titulo}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Duração: {v.duracao} | {v.data}</p>
                </div>
                <Button variant="outline" size="sm">Assistir</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Material Didático */}
      {view === "materiais" && (
        <div className="space-y-3">
          <h4 className="font-semibold text-foreground">Material Didático</h4>
          {curso.materiais.map((m, i) => (
            <Card key={i}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-2 rounded-lg bg-accent">
                  <FileText className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground text-sm">{m.titulo}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{m.tipo} — {m.tamanho}</p>
                </div>
                <Button variant="outline" size="sm">Baixar</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Fóruns */}
      {view === "foruns" && (
        <div className="space-y-4">
          <h4 className="font-semibold text-foreground">Fóruns de Discussão</h4>

          <div className="flex gap-2">
            <Input
              value={novoForum}
              onChange={(e) => setNovoForum(e.target.value)}
              placeholder="Criar novo tópico..."
              className="flex-1"
              onKeyDown={(e) => e.key === "Enter" && handleCriarForum()}
            />
            <Button onClick={handleCriarForum} size="sm">
              <Plus className="w-4 h-4 mr-1" />
              Criar
            </Button>
          </div>

          {foruns[selectedCurso].map((f, i) => (
            <Card key={i}>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="p-2 rounded-lg bg-accent">
                  <MessageSquare className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground text-sm">{f.titulo}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    por {f.autor} — {f.data} — {f.respostas} resposta{f.respostas !== 1 ? "s" : ""}
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  <Send className="w-3 h-3 mr-1" />
                  Abrir
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default CCEADTab;
