import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { FileText, Send, Clock, CheckCircle, XCircle, Plus } from "lucide-react";

type Requerimento = {
  id: number;
  tipo: string;
  data: string;
  status: "Pendente" | "Aprovado" | "Negado";
  obs: string;
};

const tiposRequerimento = [
  "Segunda Chamada de Prova",
  "Atestado de Matrícula",
  "Transferência Interna",
  "Transferência Externa",
  "Trancamento de Disciplina",
  "Trancamento Geral",
  "Aproveitamento de Disciplina",
  "Revisão de Nota",
  "Declaração de Vínculo",
  "Abono de Faltas",
];

const initialReqs: Requerimento[] = [
  { id: 1, tipo: "Segunda Chamada de Prova", data: "15/03/2026", status: "Aprovado", obs: "Banco de Dados II — G1" },
  { id: 2, tipo: "Atestado de Matrícula", data: "20/03/2026", status: "Pendente", obs: "Para estágio" },
  { id: 3, tipo: "Abono de Faltas", data: "10/02/2026", status: "Negado", obs: "Redes de Computadores" },
];

const RequerimentosTab = () => {
  const [requerimentos, setRequerimentos] = useState<Requerimento[]>(initialReqs);
  const [showForm, setShowForm] = useState(false);
  const [tipo, setTipo] = useState("");
  const [obs, setObs] = useState("");
  const [disciplina, setDisciplina] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tipo) { toast.error("Selecione o tipo de requerimento"); return; }
    const novo: Requerimento = {
      id: Date.now(),
      tipo,
      data: new Date().toLocaleDateString("pt-BR"),
      status: "Pendente",
      obs: disciplina ? `${disciplina} — ${obs}` : obs,
    };
    setRequerimentos([novo, ...requerimentos]);
    setShowForm(false);
    setTipo(""); setObs(""); setDisciplina("");
    toast.success("Requerimento enviado com sucesso!");
  };

  const statusIcon = (s: string) => {
    if (s === "Aprovado") return <CheckCircle className="w-4 h-4 text-puc-success" />;
    if (s === "Negado") return <XCircle className="w-4 h-4 text-destructive" />;
    return <Clock className="w-4 h-4 text-puc-warning" />;
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-xl font-bold text-foreground">Requerimentos Acadêmicos</h3>
        <Button onClick={() => setShowForm(!showForm)} size="sm">
          <Plus className="w-4 h-4 mr-1" />
          Novo Requerimento
        </Button>
      </div>

      {showForm && (
        <Card className="border-puc-gold/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold text-foreground flex items-center gap-2">
              <Send className="w-4 h-4" />
              Solicitar Requerimento
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-foreground">Tipo de Requerimento</Label>
                <Select value={tipo} onValueChange={setTipo}>
                  <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                  <SelectContent>
                    {tiposRequerimento.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-foreground">Disciplina (se aplicável)</Label>
                <Input value={disciplina} onChange={(e) => setDisciplina(e.target.value)} placeholder="Nome da disciplina" />
              </div>
              <div className="space-y-2">
                <Label className="text-foreground">Observações</Label>
                <Textarea value={obs} onChange={(e) => setObs(e.target.value)} placeholder="Justificativa ou informações adicionais" rows={3} />
              </div>
              <div className="flex gap-2">
                <Button type="submit">
                  <Send className="w-4 h-4 mr-1" />
                  Enviar
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Cancelar</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* List */}
      <div className="space-y-3">
        {requerimentos.map((r) => (
          <Card key={r.id}>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-2 rounded-lg bg-accent">
                <FileText className="w-5 h-5 text-accent-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground text-sm">{r.tipo}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{r.obs}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="flex items-center gap-1.5">
                  {statusIcon(r.status)}
                  <span className={
                    r.status === "Aprovado" ? "puc-badge-success" :
                    r.status === "Negado" ? "text-xs font-medium text-destructive" : "puc-badge-warning"
                  }>{r.status}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{r.data}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RequerimentosTab;
