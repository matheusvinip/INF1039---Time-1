import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { LogOut, User } from "lucide-react";
import pucLogo from "@/assets/puc-logo.png";
import { supabase } from "@/integrations/supabase/client";
import type { UserProfile } from "@/pages/Dashboard";

interface DashboardHeaderProps {
  profile: UserProfile;
}

const DashboardHeader = ({ profile }: DashboardHeaderProps) => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  return (
    <header className="puc-gradient-bg text-primary-foreground">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={pucLogo} alt="PUC" className="w-10 h-10" />
          <div>
            <h1 className="font-display text-xl font-bold leading-tight">PUC Online</h1>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden sm:flex items-center gap-2 text-sm">
            <User className="w-4 h-4" />
            <span>{profile.nome} {profile.sobrenome}</span>
            <span className="opacity-60">|</span>
            <span className="opacity-80">{profile.matricula}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="text-primary-foreground hover:bg-primary-foreground/10"
          >
            <LogOut className="w-4 h-4 mr-1" />
            Sair
          </Button>
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;
