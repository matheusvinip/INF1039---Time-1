import { useState } from "react";
import {
  BookOpen, BarChart3, AlertTriangle, CheckCircle, Clock, FileText,
  ChevronRight, TrendingUp, Calendar
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

type SAUSection = "situacao" | "faltas" | "graus" | "disciplinas" | "historico";

const menuItems = [
  { id: "situacao" as const, label: "Situação Acadêmica", icon: CheckCircle },
  { id: "faltas" as const, label: "Controle de Faltas", icon: AlertTriangle },
  { id: "graus" as const, label: "Consulta de Graus", icon: BarChart3 },
  { id: "disciplinas" as const, label: "Disciplinas a Cursar", icon: BookOpen },
  { id: "historico" as const, label: "Histórico Escolar", icon: FileText },
];

const SAUTab = () => {
  const [active, setActive] = useState<SAUSection>("situacao");

  return (
    <div className="flex flex-col lg:flex-row gap-6 animate-fade-in">
      {/* Side menu */}
      <nav className="lg:w-64 flex-shrink-0">
        <div className="puc-card p-2 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActive(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-colors text-left ${
                active === item.id
                  ? "bg-accent text-accent-foreground font-semibold"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              <span>{item.label}</span>
              <ChevronRight className="w-3 h-3 ml-auto" />
            </button>
          ))}
        </div>
      </nav>

      {/* Content */}
      <div className="flex-1 min-w-0">
        {active === "situacao" && <SituacaoAcademica />}
        {active === "faltas" && <ControleFaltas />}
        {active === "graus" && <ConsultaGraus />}
        {active === "disciplinas" && <DisciplinasACursar />}
        {active === "historico" && <HistoricoEscolar />}
      </div>
    </div>
  );
};

const SituacaoAcademica = () => (
  <div className="space-y-4">
    <h3 className="font-display text-xl font-bold text-foreground">Situação Acadêmica</h3>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {[
        { label: "Curso", value: "Engenharia de Software", icon: BookOpen },
        { label: "Período Atual", value: "6º Período", icon: Calendar },
        { label: "CR Acumulado", value: "7.8", icon: TrendingUp },
        { label: "Situação", value: "Regular", badge: "success" },
        { label: "Créditos Cursados", value: "120 / 200" },
        { label: "Previsão de Formatura", value: "2027.2" },
      ].map((item, i) => (
        <Card key={i}>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground mb-1">{item.label}</p>
            <div className="flex items-center gap-2">
              <p className="text-lg font-semibold text-foreground">{item.value}</p>
              {item.badge === "success" && <span className="puc-badge-success">Ativo</span>}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
    <Card>
      <CardContent className="p-4">
        <p className="text-sm text-muted-foreground mb-2">Progresso do Curso</p>
        <Progress value={60} className="h-3" />
        <p className="text-xs text-muted-foreground mt-1">60% concluído</p>
      </CardContent>
    </Card>
  </div>
);

const ControleFaltas = () => {
  const disciplinas = [
    { nome: "Banco de Dados II", faltas: 4, limite: 18, percentual: 22 },
    { nome: "Engenharia de Software", faltas: 2, limite: 18, percentual: 11 },
    { nome: "Redes de Computadores", faltas: 8, limite: 18, percentual: 44 },
    { nome: "Inteligência Artificial", faltas: 0, limite: 18, percentual: 0 },
    { nome: "Compiladores", faltas: 6, limite: 18, percentual: 33 },
  ];

  return (
    <div className="space-y-4">
      <h3 className="font-display text-xl font-bold text-foreground">Controle de Faltas — 2026.1</h3>
      <div className="space-y-3">
        {disciplinas.map((d, i) => (
          <Card key={i}>
            <CardContent className="p-4 flex items-center justify-between gap-4">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground text-sm">{d.nome}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Progress value={d.percentual} className="h-2 flex-1" />
                  <span className="text-xs text-muted-foreground whitespace-nowrap">{d.faltas}/{d.limite}</span>
                </div>
              </div>
              <span className={d.percentual > 30 ? "puc-badge-warning" : "puc-badge-success"}>
                {d.percentual > 30 ? "Atenção" : "OK"}
              </span>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

const ConsultaGraus = () => {
  const graus = [
    { disc: "Banco de Dados II", g1: 8.5, g2: 7.0, media: 7.75, status: "Aprovado" },
    { disc: "Engenharia de Software", g1: 9.0, g2: 8.5, media: 8.75, status: "Aprovado" },
    { disc: "Redes de Computadores", g1: 5.0, g2: null, media: null, status: "Cursando" },
    { disc: "Inteligência Artificial", g1: 7.5, g2: null, media: null, status: "Cursando" },
    { disc: "Compiladores", g1: 6.0, g2: 4.5, media: 5.25, status: "Prova Final" },
  ];

  return (
    <div className="space-y-4">
      <h3 className="font-display text-xl font-bold text-foreground">Consulta de Graus — 2026.1</h3>
      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-3 font-semibold text-foreground">Disciplina</th>
                <th className="text-center p-3 font-semibold text-foreground">G1</th>
                <th className="text-center p-3 font-semibold text-foreground">G2</th>
                <th className="text-center p-3 font-semibold text-foreground">Média</th>
                <th className="text-center p-3 font-semibold text-foreground">Situação</th>
              </tr>
            </thead>
            <tbody>
              {graus.map((g, i) => (
                <tr key={i} className="border-b last:border-0">
                  <td className="p-3 text-foreground">{g.disc}</td>
                  <td className="p-3 text-center text-foreground">{g.g1?.toFixed(1) ?? "—"}</td>
                  <td className="p-3 text-center text-foreground">{g.g2?.toFixed(1) ?? "—"}</td>
                  <td className="p-3 text-center font-medium text-foreground">{g.media?.toFixed(2) ?? "—"}</td>
                  <td className="p-3 text-center">
                    <span className={
                      g.status === "Aprovado" ? "puc-badge-success" :
                      g.status === "Prova Final" ? "puc-badge-warning" : "puc-badge-info"
                    }>{g.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
};

const DisciplinasACursar = () => {
  const disciplinas = [
    { nome: "Projeto de Software", periodo: "7º", creditos: 4, prereq: "Eng. de Software" },
    { nome: "Segurança da Informação", periodo: "7º", creditos: 4, prereq: "Redes" },
    { nome: "TCC I", periodo: "8º", creditos: 2, prereq: "Nenhum" },
    { nome: "TCC II", periodo: "9º", creditos: 4, prereq: "TCC I" },
    { nome: "Estágio Supervisionado", periodo: "9º", creditos: 6, prereq: "120 créditos" },
    { nome: "Computação em Nuvem", periodo: "7º", creditos: 4, prereq: "Redes" },
    { nome: "DevOps", periodo: "8º", creditos: 4, prereq: "Projeto de Software" },
  ];

  return (
    <div className="space-y-4">
      <h3 className="font-display text-xl font-bold text-foreground">Disciplinas a Cursar</h3>
      <div className="grid sm:grid-cols-2 gap-3">
        {disciplinas.map((d, i) => (
          <Card key={i}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-medium text-foreground text-sm">{d.nome}</p>
                  <p className="text-xs text-muted-foreground mt-1">Pré-requisito: {d.prereq}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <span className="puc-badge-info">{d.periodo} Per.</span>
                  <p className="text-xs text-muted-foreground mt-1">{d.creditos} créd.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

const HistoricoEscolar = () => {
  const periodos = [
    {
      periodo: "2023.1", disciplinas: [
        { nome: "Cálculo I", nota: 7.5, status: "Aprovado" },
        { nome: "Programação I", nota: 9.0, status: "Aprovado" },
        { nome: "Lógica", nota: 8.0, status: "Aprovado" },
      ],
    },
    {
      periodo: "2023.2", disciplinas: [
        { nome: "Cálculo II", nota: 6.5, status: "Aprovado" },
        { nome: "Programação II", nota: 8.5, status: "Aprovado" },
        { nome: "Estrutura de Dados", nota: 7.0, status: "Aprovado" },
      ],
    },
  ];

  return (
    <div className="space-y-4">
      <h3 className="font-display text-xl font-bold text-foreground">Histórico Escolar</h3>
      {periodos.map((p, i) => (
        <Card key={i}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-primary flex items-center gap-2">
              <Clock className="w-4 h-4" />
              {p.periodo}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              {p.disciplinas.map((d, j) => (
                <div key={j} className="flex items-center justify-between text-sm py-1 border-b last:border-0">
                  <span className="text-foreground">{d.nome}</span>
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-foreground">{d.nota.toFixed(1)}</span>
                    <span className="puc-badge-success">{d.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default SAUTab;
