import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Video, FileText, MessageSquare, ExternalLink, Clock } from "lucide-react";

const cursos = [
  {
    nome: "Banco de Dados II",
    professor: "Prof. Dr. Carlos Mendes",
    atividades: 3,
    proximaEntrega: "12/04/2026",
    progresso: 65,
  },
  {
    nome: "Engenharia de Software",
    professor: "Profa. Dra. Ana Lúcia",
    atividades: 1,
    proximaEntrega: "15/04/2026",
    progresso: 72,
  },
  {
    nome: "Redes de Computadores",
    professor: "Prof. Ms. Roberto Silva",
    atividades: 2,
    proximaEntrega: "10/04/2026",
    progresso: 45,
  },
  {
    nome: "Inteligência Artificial",
    professor: "Prof. Dr. Paulo Fernandes",
    atividades: 0,
    proximaEntrega: "20/04/2026",
    progresso: 80,
  },
];

const recursos = [
  { icon: Video, label: "Videoaulas", desc: "Aulas gravadas disponíveis" },
  { icon: FileText, label: "Material Didático", desc: "PDFs, slides e apostilas" },
  { icon: MessageSquare, label: "Fóruns", desc: "Discussões com colegas e professores" },
  { icon: BookOpen, label: "Biblioteca Virtual", desc: "Acervo digital de livros" },
];

const CCEADTab = () => {
  return (
    <div className="space-y-6 animate-fade-in">
      <h3 className="font-display text-xl font-bold text-foreground">CCEAD — Ambiente de Aprendizagem Online</h3>

      {/* Resources */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {recursos.map((r, i) => (
          <Card key={i} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4 text-center">
              <r.icon className="w-8 h-8 mx-auto mb-2 text-primary" />
              <p className="font-medium text-foreground text-sm">{r.label}</p>
              <p className="text-xs text-muted-foreground mt-1">{r.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Courses */}
      <div>
        <h4 className="font-semibold text-foreground mb-3">Minhas Disciplinas</h4>
        <div className="space-y-3">
          {cursos.map((c, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground">{c.nome}</p>
                    <p className="text-xs text-muted-foreground">{c.professor}</p>
                    <div className="flex items-center gap-4 mt-2">
                      {c.atividades > 0 && (
                        <span className="puc-badge-warning">
                          {c.atividades} atividade{c.atividades > 1 ? "s" : ""} pendente{c.atividades > 1 ? "s" : ""}
                        </span>
                      )}
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        Entrega: {c.proximaEntrega}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-lg font-bold text-primary">{c.progresso}%</p>
                      <p className="text-xs text-muted-foreground">concluído</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <ExternalLink className="w-3 h-3 mr-1" />
                      Acessar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CCEADTab;
