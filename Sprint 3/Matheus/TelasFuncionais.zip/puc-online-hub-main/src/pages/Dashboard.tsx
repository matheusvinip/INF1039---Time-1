import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import DashboardHeader from "@/components/DashboardHeader";
import SAUTab from "@/components/tabs/SAUTab";
import RequerimentosTab from "@/components/tabs/RequerimentosTab";
import CCEADTab from "@/components/tabs/CCEADTab";
import DiplomasTab from "@/components/tabs/DiplomasTab";
import { BookOpen, FileText, Monitor, Award } from "lucide-react";

const tabs = [
  { id: "sau", label: "SAU", fullLabel: "Sistema Acadêmico Universitário", icon: BookOpen },
  { id: "requerimentos", label: "Requerimentos", fullLabel: "Requerimentos Acadêmicos", icon: FileText },
  { id: "ccead", label: "CCEAD", fullLabel: "Ambiente de Aprendizagem Online", icon: Monitor },
  { id: "diplomas", label: "Diplomas", fullLabel: "Consulta de Diplomas Emitidos", icon: Award },
];

const Dashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("sau");

  useEffect(() => {
    const user = localStorage.getItem("puc_user");
    if (!user) navigate("/");
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      {/* Tab Navigation */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4">
          <nav className="flex overflow-x-auto gap-0 -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab.id ? "puc-tab-active" : "puc-tab-inactive hover:text-foreground"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
                <span className="sm:hidden">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Tab subtitle */}
      <div className="container mx-auto px-4 pt-4 pb-2">
        <p className="text-xs text-muted-foreground">
          {tabs.find((t) => t.id === activeTab)?.fullLabel}
        </p>
      </div>

      {/* Content */}
      <main className="container mx-auto px-4 pb-8">
        {activeTab === "sau" && <SAUTab />}
        {activeTab === "requerimentos" && <RequerimentosTab />}
        {activeTab === "ccead" && <CCEADTab />}
        {activeTab === "diplomas" && <DiplomasTab />}
      </main>
    </div>
  );
};

export default Dashboard;
