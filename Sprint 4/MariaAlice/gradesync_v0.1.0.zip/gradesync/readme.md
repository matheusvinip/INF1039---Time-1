# GradeSync

## Requisitos

Antes de subir a aplicacao, verifique se o sistema possui:

- Docker
- Docker Compose
- Python 3
- Git

Para conferir rapidamente:

```powershell
docker --version
docker compose version
python --version
git --version
```

Se algum comando nao for reconhecido, instale ou ajuste o PATH da ferramenta antes de continuar.

## Subindo a aplicacao

Na raiz do projeto, execute:

```powershell
docker compose up -d --build
```

Esse comando cria e inicia:

- `db`: banco PostgreSQL
- `web`: aplicacao Django

Depois aplique as migrations:

```powershell
docker compose exec web python manage.py migrate
```

A aplicacao ficara disponivel em:

```text
http://localhost:8000
```

## Rodando verificacoes

Para verificar a configuracao do Django:

```powershell
docker compose exec web python manage.py check
```

Para conferir se as migrations estao sincronizadas com os models:

```powershell
docker compose exec web python manage.py makemigrations --check --dry-run
```

Para rodar os testes:

```powershell
docker compose exec web python manage.py test -v 2
```

## Parando a aplicacao

Para parar os containers:

```powershell
docker compose down
```

Para parar e remover tambem o volume do PostgreSQL:

```powershell
docker compose down -v
```

Use `down -v` apenas quando quiser apagar os dados locais do banco.
