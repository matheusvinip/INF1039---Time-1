# Changelog

Todas as mudancas relevantes deste projeto serao documentadas neste arquivo.

## [Unreleased]

### Added

- Espaco reservado para as proximas funcionalidades, ajustes e correcoes.

## [0.1.0] - 2026-05-04

### Added

- Criacao da base inicial do projeto GradeSync com Django.
- Configuracao minima do projeto Django em `gradesync/`.
- Configuracao da aplicacao `app` com `AppConfig`, `models`, `admin`, `tests` e migrations.
- Configuracao de PostgreSQL como banco principal via variaveis de ambiente.
- Configuracao de Docker e Docker Compose para subir:
  - aplicacao Django no servico `web`;
  - banco PostgreSQL no servico `db`.
- Criacao da migration inicial `app.0001_initial`.
- Registro das entidades no Django Admin.
- Criacao de testes automatizados para validacoes essenciais.
- Documentacao no `readme.md` com requisitos, comandos para subir a aplicacao, rodar migrations, checks e testes.

### Changed


### Security

- Remocao do armazenamento direto de senha em `Aluno`.
- Uso do sistema de autenticacao do Django para gerenciamento de senha com hash.

### Validations


### Verified

- `docker compose config` executado com sucesso.
- `docker compose up -d --build` executado com sucesso.
- `python manage.py check` executado com sucesso dentro do container.
- `python manage.py makemigrations --check --dry-run` executado com sucesso dentro do container.
- `python manage.py migrate` executado com sucesso dentro do container.
- `python manage.py test -v 2` executado com sucesso dentro do container.
