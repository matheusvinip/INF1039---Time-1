from django.contrib import admin

from app.models import (
    Aluno,
    Avaliacao,
    CargaHoraria,
    Disciplina,
    Grade,
    Professor,
    Simulacao,
    Turma,
)


admin.site.register(Aluno)
admin.site.register(Avaliacao)
admin.site.register(CargaHoraria)
admin.site.register(Disciplina)
admin.site.register(Grade)
admin.site.register(Professor)
admin.site.register(Simulacao)
admin.site.register(Turma)
