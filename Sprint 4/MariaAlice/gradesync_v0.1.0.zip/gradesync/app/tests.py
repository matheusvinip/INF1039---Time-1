from datetime import time

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase

from app.models import Aluno, Avaliacao, CargaHoraria, Disciplina, Grade, Professor


class EntityValidationTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="aluno1",
            email="aluno1@example.com",
            password="senha-forte-de-teste",
        )
        self.aluno = Aluno.objects.create(usuario=self.user, matricula="2026001")
        self.disciplina = Disciplina.objects.create(
            codigo="INF1039",
            nome="Projeto de Software",
            taxa_de_reprovacao=0,
        )
        self.professor = Professor.objects.create(nome="Professor Teste", avaliacao=8)
        self.grade = Grade.objects.create(periodo="2026.1", aluno=self.aluno)

    def test_aluno_usa_senha_do_usuario_django(self):
        self.assertFalse(hasattr(self.aluno, "senha"))
        self.assertTrue(self.user.check_password("senha-forte-de-teste"))

    def test_avaliacao_rejeita_nota_fora_da_escala(self):
        avaliacao = Avaliacao(
            ano=2026,
            semestre=1,
            nota=11,
            avaliacao_completa=True,
            aluno=self.aluno,
            professor=self.professor,
            disciplina=self.disciplina,
        )

        with self.assertRaises(ValidationError):
            avaliacao.full_clean()

    def test_carga_horaria_rejeita_intervalo_invalido(self):
        carga_horaria = CargaHoraria(
            dia="segunda",
            hora_inicio=time(10, 0),
            hora_final=time(9, 0),
        )

        with self.assertRaises(ValidationError):
            carga_horaria.full_clean()
