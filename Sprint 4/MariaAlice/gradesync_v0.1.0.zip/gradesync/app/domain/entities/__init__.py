from app.domain.entities.aluno import Aluno
from app.domain.entities.avaliacao import Avaliacao
from app.domain.entities.cargahoraria import CargaHoraria
from app.domain.entities.disciplina import Disciplina
from app.domain.entities.grade import Grade
from app.domain.entities.professor import Professor
from app.domain.entities.simulacao import Simulacao
from app.domain.entities.turma import Turma

__all__ = [
    "Aluno",
    "Avaliacao",
    "CargaHoraria",
    "Disciplina",
    "Grade",
    "Professor",
    "Simulacao",
    "Turma",
]
